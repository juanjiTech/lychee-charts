{{- define "lychee-moments-plus.configdata" -}}
{{- $redisAddr := .Values.redisConnection.addr -}}
{{- $redisPassword := .Values.redisConnection.password -}}
{{- $pgHost := .Values.database.host -}}
{{- $pgPort := .Values.database.port -}}
{{- $pgUser := .Values.database.user -}}
{{- $pgPassword := .Values.database.password -}}
{{- $pgDatabase := .Values.database.database -}}
{{- $pgSSLMode := .Values.database.sslMode | default "disable" -}}
{{- if .Values.redis.enabled -}}
{{- $redisAddr = printf "%s-redis-master:6379" .Release.Name -}}
{{- if .Values.redis.auth.enabled -}}
{{- $redisPassword = .Values.redis.auth.password -}}
{{- end -}}
{{- end -}}
{{- if .Values.postgresql.enabled -}}
{{- $pgHost = printf "%s-postgresql" .Release.Name -}}
{{- $pgPort = "5432" -}}
{{- $pgUser = .Values.postgresql.auth.username -}}
{{- $pgPassword = .Values.postgresql.auth.password -}}
{{- $pgDatabase = .Values.postgresql.auth.database -}}
{{- end -}}
Mode: {{ .Values.mode | quote }}
Server:
  Addr: {{ .Values.server.addr | quote }}
Log:
  Level: {{ .Values.logging.level | quote }}
  Format: {{ .Values.logging.format | quote }}
PostgreSQL:
  Host: {{ $pgHost | quote }}
  Port: {{ $pgPort | quote }}
  User: {{ $pgUser | quote }}
  Pass: {{ $pgPassword | quote }}
  Database: {{ $pgDatabase | quote }}
  SSLMode: {{ $pgSSLMode | quote }}
  Debug: {{ .Values.database.debug }}
Redis:
  Addr: {{ $redisAddr | quote }}
  Password: {{ $redisPassword | quote }}
  DB: {{ .Values.redisConnection.db }}
  Protocol: {{ .Values.redisConnection.protocol }}
Storage:
  {{- if .Values.storage }}
  {{- range .Values.storage }}
  - StorageKey: {{ .StorageKey | quote }}
    StorageType: {{ .StorageType | quote }}
    {{- if .AliOSS }}
    AliOSS:
      {{- toYaml .AliOSS | nindent 6 }}
    {{- end }}
    {{- if .S3 }}
    S3:
      {{- toYaml .S3 | nindent 6 }}
    {{- end }}
    {{- if .Minio }}
    Minio:
      {{- toYaml .Minio | nindent 6 }}
    {{- end }}
    {{- if .Tos }}
    Tos:
      {{- toYaml .Tos | nindent 6 }}
    {{- end }}
  {{- end }}
  {{- end }}
EventBus:
  Type: {{ .Values.eventBus.type | quote }}
  Server: {{ .Values.eventBus.server | quote }}
Notification:
  {{- if .Values.notification.providers }}
  {{- range .Values.notification.providers }}
  - ProviderKey: {{ .ProviderKey | quote }}
    {{- if .AliyunSMS }}
    AliyunSMS:
      {{- toYaml .AliyunSMS | nindent 6 }}
    {{- end }}
    {{- if .TencentSMS }}
    TencentSMS:
      {{- toYaml .TencentSMS | nindent 6 }}
    {{- end }}
    {{- if .SMTP }}
    SMTP:
      {{- toYaml .SMTP | nindent 6 }}
    {{- end }}
  {{- end }}
  {{- else }}
  - ProviderKey: "console"
  {{- end }}
Auth:
  JWTSecret: {{ .Values.jwt.secret | quote }}
  JWTRealm: {{ .Values.jwt.realm | quote }}
  AccessTokenExpire: {{ .Values.jwt.accessTokenExpire | quote }}
  RefreshTokenExpire: {{ .Values.jwt.refreshTokenExpire | quote }}
  VerificationCodeExpire: {{ .Values.jwt.verificationCodeExpire | quote }}
  VerificationCodeLength: {{ .Values.jwt.verificationCodeLength }}
  VerificationCodeRateLimit: {{ .Values.jwt.verificationCodeRateLimit | quote }}
  OAuth:
    Providers: []
{{- end }}
